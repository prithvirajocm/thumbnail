({
    getRecords : function(component,event,helper){
        var sortByValues = JSON.parse(component.get("v.sortByValues"));
        component.set("v.sortByValue",sortByValues[0].value);
        component.set("v.sortByOptions",sortByValues);
        var action = component.get("c.getRecordDetails");
        var searchValue = component.get("v.searchValue");
        var whereCondition = component.get("v.whereCondition");
        if( !component.get("v.whereCondition") )
            whereCondition = '';
        if( searchValue != undefined && searchValue != '' ){
            //whereCondition = 'AccountId='+component.get("v.accountId");
            whereCondition = component.get("v.filterByField");
            whereCondition = whereCondition+' like \'%'+component.get("v.searchValue")+'%\'';
        }
        action.setParams({
            'sObjectName' : component.get("v.sObjectName"),
            'accountId' : component.get("v.accountId"),
            'commaSeperatedFields' : component.get("v.commaSeperatedFields"),
            'whereCondition' : whereCondition,
        });
        action.setCallback(this, function(response) {
            var state = response.getState();
            if(component.isValid() && state === 'SUCCESS') {
                var result = JSON.parse(response.getReturnValue())
                component.set("v.recordSize",result.length);
                component.set("v.recordDetails", result);
                component.set("v.maxPage", Math.floor((result.length+4)/5));
                this.sortBy(component, "CreatedDate");
            }
        });
        $A.enqueueAction(action);       
    },
    sortBy: function(component, field) {
        var sortAsc = component.get("v.sortAsc"),
            sortField = component.get("v.sortField"),
            records = component.get("v.recordDetails");
        sortAsc = sortField != field || !sortAsc;
        records.sort(function(a,b){
            var t1 = a[field] == b[field],
                t2 = (!a[field] && b[field]) || (a[field] < b[field]);
            return t1? 0: (sortAsc?-1:1)*(t2?1:-1);
        });
        component.set("v.sortAsc", sortAsc);
        component.set("v.sortField", field);
        component.set("v.recordDetails", records);
        this.renderPage(component);
    },
    renderPage: function(component) {
        var records = component.get("v.recordDetails"),
            pageNumber = component.get("v.pageNumber"),
            pageRecords = records.slice((pageNumber-1)*5, pageNumber*5);
        component.set("v.currentList", pageRecords);
    }
})