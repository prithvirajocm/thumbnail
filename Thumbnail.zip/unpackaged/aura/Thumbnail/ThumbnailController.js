({
	doInit : function(component,event,helper){
       helper.getRecords(component,helper);       
    },
    
    //Open URL in New Browser Tab
    handleOpenInNewWindow : function(component, event, helper) {
        var url = event.target.id;
        if(url.includes('https://'))
            window.open(url, '_blank');
        else
            window.open('https://'+url, '_blank');        
    },
    renderPage: function(component, event, helper) {
        helper.renderPage(component);
    },
    // this function automatic call by aura:waiting event  
    showSpinner: function(component, event, helper) {
       // make Spinner attribute true for display loading spinner 
        component.set("v.Spinner", true); 
   },
    
    // this function automatic call by aura:doneWaiting event 
    hideSpinner : function(component,event,helper){
     // make Spinner attribute to false for hide loading spinner    
       component.set("v.Spinner", false);
    },
    onChange: function (component,event,helper) {
        helper.sortBy(component, component.find('select').get('v.value'));
    },
    searchRecords:function (component,event,helper) {
        helper.getRecords(component,helper);
    },

})